# Komal portfolio webpage

A portfolio web site completely made in html css and javascript from ground up.

<br>

## This is how it looks

<br>

### In dark mode

![In dark mode](./preview/dark.png)

### In light mode

![In light mode](./preview/light.png)
